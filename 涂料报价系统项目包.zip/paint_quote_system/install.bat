@echo off
chcp 65001 >nul
title 进口涂料报价系统 - 安装程序

echo ========================================
echo    进口涂料自动报价系统
echo    安装向导
echo ========================================
echo.

echo [1/4] 正在检查Python环境...
python --version >nul 2>&1
if errorlevel 1 (
    echo 错误：未检测到Python，请先安装Python
    echo 下载地址：https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)
echo ✓ Python已安装

echo.
echo [2/4] 正在安装依赖...
pip install fastapi uvicorn sqlalchemy openpyxl pillow pydantic apscheduler requests -q
if errorlevel 1 (
    echo 错误：依赖安装失败
    pause
    exit /b 1
)
echo ✓ 依赖安装完成

echo.
echo [3/4] 正在创建数据目录...
if not exist "data" mkdir data
if not exist "exports\quotes" mkdir exports\quotes
if not exist "exports\reports" mkdir exports\reports
echo ✓ 目录创建完成

echo.
echo [4/4] 初始化数据库...
python -c "import sys; sys.path.insert(0, 'backend'); from database import init_db; init_db()" 2>nul
echo ✓ 数据库初始化完成

echo.
echo ========================================
echo    安装完成！
echo ========================================
echo.
echo 启动系统：请运行 start.bat
echo 访问地址：http://localhost:8000
echo.
pause

@echo off
title 进口涂料报价系统

echo ========================================
echo    进口涂料自动报价系统
echo ========================================
echo.
echo 正在启动服务...
echo 启动完成后请访问：http://localhost:8000
echo.
echo 按 Ctrl+C 可停止服务
echo.

python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload

pause
