"""
产品批量导入脚本
从Excel文件导入产品数据
"""
import sys
import openpyxl
from pathlib import Path

# 添加backend到路径
sys.path.insert(0, str(Path(__file__).parent / "backend"))

from database import SessionLocal, init_db
from models import Product


def import_from_excel(excel_file: str):
    """从Excel导入产品"""
    init_db()
    db = SessionLocal()

    try:
        wb = openpyxl.load_workbook(excel_file)
        ws = wb.active

        # 跳过表头，从第二行开始
        imported = 0
        skipped = 0

        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row[0]:  # 如果型号为空，跳过
                continue

            model_code = str(row[0]).strip()
            product_name = str(row[1]).strip() if row[1] else ""
            series_name = str(row[2]).strip() if row[2] else ""
            cost_price = float(row[3]) if row[3] else 0
            default_price = float(row[4]) if row[4] else None

            # 检查是否已存在
            existing = db.query(Product).filter(Product.model_code == model_code).first()
            if existing:
                print(f"跳过: {model_code} (已存在)")
                skipped += 1
                continue

            # 添加产品
            product = Product(
                model_code=model_code,
                product_name=product_name,
                series_name=series_name,
                cost_price=cost_price,
                default_price=default_price
            )
            db.add(product)
            imported += 1
            print(f"添加: {model_code} - {product_name}")

        db.commit()
        print(f"\n导入完成! 新增: {imported}, 跳过: {skipped}")

    except Exception as e:
        print(f"导入失败: {e}")
        db.rollback()
    finally:
        db.close()


def create_sample_excel():
    """创建示例Excel模板"""
    wb = Workbook()
    ws = wb.active
    ws.title = "产品列表"

    # 表头
    ws.append(["产品型号", "产品名称", "产品系列", "成本价", "建议售价"])

    # 示例数据
    examples = [
        ["5381X", "进口外墙漆", "本杰明摩尔", 400, 600],
        ["5382X", "进口内墙漆", "本杰明摩尔", 380, 550],
        ["K2", "外墙专用底漆", "本杰明摩尔", 150, 250],
        ["OC-17", "经典白色", "本杰明摩尔色号", 0, 0],
    ]

    for row in examples:
        ws.append(row)

    # 保存
    output = Path(__file__).parent.parent / "产品导入模板.xlsx"
    wb.save(output)
    print(f"模板已创建: {output}")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        # 导入模式
        import_from_excel(sys.argv[1])
    else:
        # 创建模板
        create_sample_excel()
        print("\n使用方法:")
        print("  python import_products.py          # 创建Excel模板")
        print("  python import_products.py 文件.xlsx # 导入Excel")
