# 进口涂料自动报价系统

## 项目结构
```
paint_quote_system/
├── backend/              # 后端服务
│   ├── main.py         # 主程序入口
│   ├── database.py     # 数据库配置
│   ├── models.py       # 数据模型
│   └── requirements.txt # 依赖列表
├── frontend/           # 前端页面
│   └── index.html     # 管理后台
├── data/               # 数据目录
│   └── paint.db       # SQLite数据库
└── exports/            # 导出文件
    ├── quotes/        # 报价单
    └── reports/       # 报表
```

## 快速部署

本系统已适配云端部署，支持 Railway、Render、Fly.io 等平台。

### 方式一：部署到 Railway（推荐，免费）

1. **注册 Railway 账号**
   - 访问 https://railway.app
   - 使用 GitHub 账号登录

2. **创建新项目**
   - 点击 "New Project"
   - 选择 "Deploy from GitHub repo"
   - 或者选择 "Empty Project" 然后上传本项目

3. **配置环境变量**
   - 在 Railway 面板中点击 "Variables"
   - 添加以下变量：
     - `PORT`: `8000`
     - `PYTHON_VERSION`: `3.11`

4. **部署**
   - Railway 会自动检测 Python 项目
   - 点击 Deploy 即可

### 方式二：部署到 Render

1. **注册 Render 账号**
   - 访问 https://render.com
   - 使用 GitHub 账号登录

2. **创建 Web Service**
   - 点击 "New" → "Web Service"
   - 连接你的 GitHub 仓库
   - 配置：
     - Build Command: `pip install -r backend/requirements.txt`
     - Start Command: `cd backend && python -m uvicorn main:app --host 0.0.0.0 --port $PORT`

### 方式三：使用 Fly.io

1. **安装 Fly CLI**
   - `winget install flyctl`

2. **部署**
   - `fly launch`
   - `fly deploy`

---

## 本地启动（开发测试用）

### 1. 安装依赖
```bash
cd backend
pip install -r requirements.txt
```

### 2. 启动服务
```bash
python main.py
```

### 3. 访问管理后台
浏览器打开: http://localhost:8000

## 功能清单

### 核心功能
- [x] 产品数据库管理
- [x] 飞书消息解析
- [x] 自动生成报价单(Excel/图片)
- [x] 邮件发送
- [x] 订单管理(创建/取消)
- [x] 费用记录
- [x] 日报表自动生成(每天21:00)
- [x] 月报表自动生成

### API接口
- `GET  /api/products` - 获取产品列表
- `POST /api/products` - 添加产品
- `POST /api/orders` - 创建订单
- `POST /api/orders/cancel` - 取消订单
- `POST /api/expenses` - 记录费用
- `GET  /api/reports/daily` - 获取日报表
- `GET  /api/reports/monthly` - 获取月报表

## 默认配置
- 服务端口: 8000
- 数据库: data/paint.db
- 邮件发送: 需配置SMTP

---

## 访问地址

部署成功后，访问地址为：`https://你的项目名.railway.app` 或 `https://你的项目名.onrender.com`

---

## 配置说明

首次使用请配置：

1. **飞书配置** - 系统设置 → 飞书配置
2. **邮件配置** - 系统设置 → 邮件配置
3. **产品管理** - 添加你的产品型号和成本价
4. **费用记录** - 记录每日开支

---

## 消息格式

在飞书群发送消息自动报价：

```
客户：北京仝总，5381X 6桶，色号OC-17，价格600一桶，木架费50
```

或多个产品：

```
客户：上海张总，5381X 10桶色号OC-17价格650，5382X 5桶色号K2价格550，木架费80
```
