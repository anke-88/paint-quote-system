"""
进口涂料自动报价系统 - 启动脚本
使用方法: python start.py
"""
import os
import sys
from pathlib import Path

# 确保在正确的目录
BASE_DIR = Path(__file__).parent
os.chdir(BASE_DIR)

# 添加backend到路径
sys.path.insert(0, str(BASE_DIR / "backend"))

if __name__ == "__main__":
    print("=" * 50)
    print("进口涂料自动报价系统")
    print("=" * 50)
    print()
    print("正在启动服务...")
    print()

    # 导入并运行
    import uvicorn
    from backend.main import app, init_db

    # 初始化数据库
    init_db()
    print("✓ 数据库初始化完成")
    print()

    # 启动服务
    print("=" * 50)
    print("服务地址: http://localhost:8000")
    print("管理后台: http://localhost:8000")
    print("=" * 50)
    print()

    uvicorn.run(app, host="0.0.0.0", port=8000)
