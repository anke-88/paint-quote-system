@echo off
chcp 65001 >nul
echo.
echo ========================================
echo    进口涂料报价系统 - 启动中...
echo ========================================
echo.
cd /d "%~dp0"
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000
pause
