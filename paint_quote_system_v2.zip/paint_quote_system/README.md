# 进口涂料自动报价系统

## 项目结构
```
paint_quote_system/
├── backend/              # 后端服务
│   ├── main.py         # 主程序入口
│   ├── database.py     # 数据库配置
│   ├── models.py       # 数据模型
│   ├── routers/       # API路由
│   ├── services/      # 业务逻辑
│   └── utils/         # 工具函数
├── frontend/           # 前端页面
│   └── index.html     # 管理后台
├── data/               # 数据目录
│   └── paint.db       # SQLite数据库
└── exports/            # 导出文件
    ├── quotes/        # 报价单
    └── reports/       # 报表
```

## 快速启动

### 1. 安装依赖
```bash
cd backend
pip install fastapi uvicorn sqlalchemy openpyxl pillow jinja2 aiosmtpd python-dateutil
```

### 2. 启动服务
```bash
python main.py
```

### 3. 访问管理后台
浏览器打开: http://localhost:8000

## 功能清单

### 核心功能
- [x] 产品数据库管理
- [x] 飞书消息解析
- [x] 自动生成报价单(Excel/图片)
- [x] 邮件发送
- [x] 订单管理(创建/取消)
- [x] 费用记录
- [x] 日报表自动生成(每天21:00)
- [x] 月报表自动生成

### API接口
- `GET  /api/products` - 获取产品列表
- `POST /api/products` - 添加产品
- `POST /api/orders` - 创建订单
- `POST /api/orders/cancel` - 取消订单
- `POST /api/expenses` - 记录费用
- `GET  /api/reports/daily` - 获取日报表
- `GET  /api/reports/monthly` - 获取月报表

## 默认配置
- 服务端口: 8000
- 数据库: data/paint.db
- 邮件发送: 需配置SMTP
